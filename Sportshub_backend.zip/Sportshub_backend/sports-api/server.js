const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '5247',
    database: 'sporthub'
});

app.get('/', (req, res) => {
    res.send('Hello, welcome to the API!');
});

app.get('/api/sports', (req, res) => {
    db.query('SELECT * FROM Sports', (err, results) => {
        if (err) {
            return res.status(500).send('Database query failed');
        }
        res.json(results);
    });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
